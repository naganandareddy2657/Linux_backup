docker service rm simpleweb_web 
docker network rm simpleweb_default 
